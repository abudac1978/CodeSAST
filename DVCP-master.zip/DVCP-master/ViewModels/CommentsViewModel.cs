using System;
using System.Collections.Generic;

namespace VulnerableCoreApp.ViewModels
{
    public class CommentsViewModel
    {
        public List<CommentViewModel> Comments { get; set; }
    }
}